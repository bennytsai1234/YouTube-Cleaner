## 1. Spec Population
- [x] 1.1 Create `core-filtering` spec.
- [x] 1.2 Create `ui-cleaning` spec.
- [x] 1.3 Create `adblock-guard` spec.
- [x] 1.4 Create `interaction` spec.
- [x] 1.5 Create `i18n` spec.
