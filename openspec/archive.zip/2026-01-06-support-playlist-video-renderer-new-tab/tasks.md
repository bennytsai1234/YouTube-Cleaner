# Tasks: Support New Tab for Playlist Video Renderer

- [x] Update `SELECTORS.VIDEO_CONTAINERS` in `youtube-homepage-cleaner.user.js` <!-- id: 0 -->
- [x] Update `SELECTORS.CLICKABLE` in `youtube-homepage-cleaner.user.js` <!-- id: 1 -->
- [x] Verify functionality (simulation/logic check) <!-- id: 2 -->
- [x] Update version to v1.6.4 <!-- id: 3 -->
