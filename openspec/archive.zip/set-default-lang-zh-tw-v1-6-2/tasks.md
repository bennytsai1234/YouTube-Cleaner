# Tasks: Update to v1.6.2

- [x] Update version metadata to `1.6.2` in `youtube-homepage-cleaner.user.js` <!-- id: 0 -->
- [x] Modify `I18N.detectLanguage` to add explicit `en` check and change fallback to `'zh-TW'` <!-- id: 1 -->
