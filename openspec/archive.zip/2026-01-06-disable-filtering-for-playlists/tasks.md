# Tasks: Disable Filtering for Playlist Items

- [x] Remove `ytd-playlist-video-renderer` from `SELECTORS.VIDEO_CONTAINERS` in `youtube-homepage-cleaner.user.js` <!-- id: 0 -->
- [x] Update version to v1.6.5 <!-- id: 1 -->
